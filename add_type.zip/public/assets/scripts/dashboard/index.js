var dashboard_index = function(){
    let default_daterange_chosenLabel = "Last 30 Days";
    let init_daterangepicker = function(){
        let start = moment().subtract(29, 'days');
        let end = moment();
        function cb(start, end) {
            try{
                $("#dashboard_dates span").html(start.format("MMMM D, YYYY") + " - " + end.format("MMMM D, YYYY"));
                if(page_load == 0){
                    dashboard_index.getDashBoardData();
                }
            }catch(e){ }
        }
        
        $("#dashboard_dates").daterangepicker({
            startDate: start,
            endDate: end,
            ranges: {
                "Today": [moment(), moment()],
                "Yesterday": [moment().subtract(1, "days"), moment().subtract(1, "days")],
                "Last 7 Days": [moment().subtract(6, "days"), moment()],
                "Last 30 Days": [moment().subtract(29, "days"), moment()],
                "This Month": [moment().startOf("month"), moment().endOf("month")],
                "Last Month": [moment().subtract(1, "month").startOf("month"), moment().subtract(1, "month").endOf("month")]
            }
        }, cb);
        
        // Init date-range object
        cb(start, end);
    }; // (End Of) => let init_daterangepicker = function
    
    let accounts_handler = function(){
        $(".dashboard-account").click(function(){
            let account_id = $(this).attr("data-account-id");
            let account_name = $(this).attr("data-account-name");

            $(".dashboard-account").removeClass("active");
            $(this).addClass("active");

            $("#header-dashboard-label").html(account_name);
            $("#profiles-select").empty();
            let count_options = 1;
            let first_profile_id = 0;

            if(dashboard_type == "bid" || dashboard_type == "negative"){
                let newOption =  new Option(`All Accounts`, "-1" , true,true);
                $('#profiles-select').append(newOption);
            }

            $.each(rsActiveAccountProfiles,function(obj, val){
                if(account_id == val.account_id){
                    if(count_options == 1){
                        first_profile_id = val.id;
                    }
                    
                    //let newOption =  new Option(`${val.name} (${val.countryCode})`, val.id , (count_options==1)?true:false, (count_options==1)?true:false);
                    let newOption =  new Option(`${val.name} (${val.countryCode})`, val.id , false, false);
                    $('#profiles-select').append(newOption);
                    count_options++;
                }
            });

            if(first_profile_id > 0){
                //Change sidebar enity url
                CommonScript.change_sb_entity_url(first_profile_id);
            }

            let meta_dashboard_type = $('meta[name="meta-dashboard_type"]').attr('content');
            if( meta_dashboard_type == "main_dashboard" || meta_dashboard_type == "main"){
                // Get data from the server
                dashboard_index.getDashBoardData();
            }else{
                rules_index.get_rule_summary(account_id);
            }

        });
    }; // (End Of) => let accounts_handler = function()
    
    let profile_select_handler = function(){
        $('#profiles-select').change(function(){
            //Change sidebar enity url
            CommonScript.change_sb_entity_url($(this).val());
            // Get data from the server
            if(dashboard_type == "main"){
                dashboard_index.getDashBoardData();
            }else if(dashboard_type == "bid" || dashboard_type == "negative"){
                let account_id =$("a.list-group-item.dashboard-account.active").attr("data-account-id");
                if(account_id){
                    rules_index.get_rule_summary_filer(account_id, $(this).val());
                }else{
                    alert("Unknown account id, please contact the support!");
                }
            }
            
        });
    };
    
    let badge_percentage_color = function(pValue){
        pValue = pValue * 1;
        return (pValue==0)?"badge-soft-info":((pValue>=0)?"badge-soft-success":"badge-soft-danger");
    };

    let badge_percentage_color_acos = function(pValue){
        pValue = pValue * 1;
        return  ((pValue <= 0)?"badge-soft-success":"badge-soft-danger");
    };

    let update_currency_code_view = function(currencyCode){
        let cC_html = "";
        let cC_Symbol = currency_symbol(currencyCode,"fa");
        $(".currencyCode").removeAttr('style');
        if(cC_Symbol != "???"){
            cC_html = `<i class="align-middle fas fa-fw ${cC_Symbol} fa-lg"></i>`;
        }else{
            $(".currencyCode").attr('style', 'font-size: 10px !important;font-weight: bold;padding-top: 15px !important;');
            cC_html = `${currencyCode}`;
        } 
        
        $(".currencyCode").html(cC_html);
    };

    let currency_symbol = function(currencyCode, type="html"){
        let cC_sign = (type=="html")?"&dollar;":"fa-dollar-sign";
        switch(currencyCode) {
            case "USD":
                if(type=="html"){cC_sign = "&dollar;";}else{cC_sign = "fa-dollar-sign";}
                break;
            case "EUR":
                if(type=="html"){cC_sign = "&euro;";}else{cC_sign = "fa-euro-sign";}
                break;
            case "GBP":
                if(type=="html"){cC_sign = "&pound;";}else{cC_sign = "fa-pound-sign";}
                break;
            case "AUD":
                if(type=="html"){cC_sign = "A&dollar;";}else{cC_sign = "???";}
                break;
            case "CAD":
                if(type=="html"){cC_sign = "&dollar; CA";}else{cC_sign = "???";}
                break;
            default: // "SEK", 'MXN', 'PLN', 'TRY'
                if(type=="html"){cC_sign = "???";}else{cC_sign = "???";}
        }
        return cC_sign;
    };
    
    let dashboard_display = function(pData,pRsAdspend,currencyCode){
        $.each(eval(pData),function(obj,val){
            let tmp_cnt = val.cur_cost_pct?val.cur_cost_pct:0.00;
            let cC_sign = currency_symbol(currencyCode, "html");
            let font_size = (cC_sign=="???")?" class='h4'":"";
            cC_sign = (cC_sign=="???")?currencyCode:cC_sign;
           
            $(".ad-spend").html(`<span ${font_size} >${cC_sign}</span> ${val.cur_cost}`);
            $(".ad-spend-pct").html(` ${tmp_cnt}%`);
            $(".ad-spend-pct").removeClass("badge-soft-success").removeClass("badge-soft-danger").removeClass("badge-soft-info").addClass( badge_percentage_color(tmp_cnt) );

            tmp_cnt = val.cur_acos_pct?val.cur_acos_pct:0.00;
            $(".acos").html(`${val.cur_acos}`);
            $(".acos-pct").html(` ${tmp_cnt}%`);
            $(".acos-pct").removeClass("badge-soft-success").removeClass("badge-soft-danger").removeClass("badge-soft-info").addClass( badge_percentage_color_acos(tmp_cnt) );

            tmp_cnt = val.cur_attributedSales7d_pct?val.cur_attributedSales7d_pct:0.00;
            $("#dashboard_ad_sales").val(`${val.cur_attributedSales7d_nf}`);
            $(".ad-sales").html(`<span ${font_size} >${cC_sign}</span> ${val.cur_attributedSales7d}`);
            $(".ad-sales-pct").html(` ${tmp_cnt}%`);
            $(".ad-sales-pct").removeClass("badge-soft-success").removeClass("badge-soft-danger").removeClass("badge-soft-info").addClass( badge_percentage_color(tmp_cnt) );
            
            $(".total-sales").html(`<span ${font_size} >${cC_sign}</span> 0.00`);
            $(".tacos").html(`<span ${font_size} >${cC_sign}</span> 0.00`);
            return false;
        });

        $.each(eval(pRsAdspend),function(obj,val){
            $(".wasted_ad_spend").html(`${val.Cur_AdSpend_pct}`);
            $(".wasted_ad_spend-pct").html(` ${val.Change_AdSpend_pct}%`);
            $(".wasted_ad_spend-pct").removeClass("badge-soft-success").removeClass("badge-soft-danger").removeClass("badge-soft-info").addClass( badge_percentage_color_acos(val.Change_AdSpend_pct) );
            return false;
        });
    };
    
    let format_number = function(Arg0){
        var parts = Arg0.toString().split(".");
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        return parts.join(".");
    }

    return{
        init:function(){
            init_daterangepicker();
            accounts_handler();
            profile_select_handler();
        }

        ,set_dashboard_default:function(){
            let tmp_data = [{"profile_id":0
                ,"cur_cost":"0.00","cur_acos":"0.00","cur_attributedSales7d":"0.00","prev_cost":"0.00","prev_acos":"0.00"
                ,"prev_attributedSales7d":"0.00","cur_cost_pct":"0.00","cur_acos_pct":"0.00"
                ,"cur_attributedSales7d_pct":"0.00", "currencyCode": "USD"
            }];

            let tmp_adspend = [{
                "Cur_AdSpendNoSales":"0.00","Cur_AdSpendOverAll":"0.00" ,"Cur_AdSpend_pct":"0.00" 
                ,"Prev_AdSpendNoSales":"0.00","Prev_AdSpendOverAll":"0.00" ,"Prev_AdSpend_pct":"0.00" 
            }];

            update_currency_code_view("USD");
            dashboard_display(tmp_data,tmp_adspend,"USD");
        }

        ,getDashBoardData:function(){
            try{
                let CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
                let main_url =$('meta[name="main-url"]').attr('content');
                let text_date = $('#dashboard_dates').data('daterangepicker');
                let chosenLabel = (text_date.chosenLabel)?text_date.chosenLabel:default_daterange_chosenLabel;
                let startDate =  text_date.startDate.format('YYYY/MM/DD');
                let endDate =  text_date.endDate.format('YYYY/MM/DD');
                let profile_id = $('#profiles-select').val()?$('#profiles-select').val().trim():"";
                CommonScript.hide_error_message();
                
                if(profile_id==""){
                    dashboard_index.set_dashboard_default();
                    CommonScript.set_error_message("Dashboard parameter profile is missing!");
                    return false;
                }
                
                CommonScript.blockUI();
                $.ajax({
                    url: main_url + "/home/request-actions",
                    type: 'POST',
                    data: {
                        _token: CSRF_TOKEN,
                        ajaxAction: "dashboard_data",
                        chosenLabel: chosenLabel,
                        startDate: startDate,
                        endDate: endDate,
                        profile_id: profile_id
                    },
                    success: function (response) {
                        CommonScript.unblockUI();
                        if (response.Level == "success") {
                            update_currency_code_view(response.currencyCode);
                            dashboard_display(response.results,response.rsAdSpend,response.currencyCode);
                            
                            try{
                                if($(".AdType_Automatic_Spend").length){
                                    dashboard_index.get_dashboard_performance_per_ad_type();
                                }
                            }catch(e){}
                        }else{
                            CommonScript.set_error_message(response.Message)
                        }
                    },error: function(xhr, exception,errorThrown){
                        dashboard_index.set_dashboard_default();
                        CommonScript.unblockUI();
                        let msg = '';
                        if(xhr.status === 0){
                            msg = 'Not connected.\n Verify your Network.';
                        }else if(xhr.status == 404){
                            msg = "Page not found!";
                        }else if(xhr.status == 500){
                            msg =  'Internal Server Error [500].';
                        }else if(exception === 'parsererror'){
                            msg = 'Requested JSON parse failed.';
                        }else if(exception === 'timeout'){
                            msg = 'Time out error.';
                        }else if(exception === 'abort'){
                            msg = 'Ajax request aborted.';
                        }else{
                            msg = 'Uncaught Error.\n' + xhr.responseText;
                        }
                        CommonScript.set_error_message(msg);
                    }
                });
            }catch(e){
                dashboard_index.set_dashboard_default();
                CommonScript.unblockUI();
                CommonScript.set_error_message(e);
            }
        } // (End Of) => getDashBoardData:function()

        ,set_default_performance_per_ad_type:function(pValue){
            $(".AdType_Automatic_Spend").html(pValue);
            $(".AdType_Automatic_Sales").html(pValue);
            $(".AdType_Automatic_ACoS").html(pValue);
            $(".AdType_Automatic_PBar").removeAttr('style').attr('style', "width: 0%");

            $(".AdType_Broad_Spend").html(pValue);
            $(".AdType_Broad_Sales").html(pValue);
            $(".AdType_Broad_ACoS").html(pValue);
            $(".AdType_Broad_PBar").removeAttr('style').attr('style', "width: 0%");
            
            $(".AdType_Phrase_Spend").html(pValue);
            $(".AdType_Phrase_Sales").html(pValue);
            $(".AdType_Phrase_ACoS").html(pValue);
            $(".AdType_Phrase_PBar").removeAttr('style').attr('style', "width: 0%");

            $(".AdType_Exact_Spend").html(pValue);
            $(".AdType_Exact_Sales").html(pValue);
            $(".AdType_Exact_ACoS").html(pValue);
            $(".AdType_Exact_PBar").removeAttr('style').attr('style', "width: 0%");

            $(".AdType_SB_Spend").html(pValue);
            $(".AdType_SB_Sales").html(pValue);
            $(".AdType_SB_ACoS").html(pValue);
            $(".AdType_SB_PBar").removeAttr('style').attr('style', "width: 0%");

            $(".AdType_SBV_Spend").html(pValue);
            $(".AdType_SBV_Sales").html(pValue);
            $(".AdType_SBV_ACoS").html(pValue);
            $(".AdType_SBV_PBar").removeAttr('style').attr('style', "width: 0%");
        }

        ,set_loading_performance_per_ad_type:function(){
            dashboard_index.set_default_performance_per_ad_type("");

            $(".AdType_Automatic_Spend").removeClass("spinner-border spinner-border-sm").addClass("spinner-border spinner-border-sm");
            $(".AdType_Automatic_Sales").removeClass("spinner-border spinner-border-sm").addClass("spinner-border spinner-border-sm");
            $(".AdType_Automatic_ACoS").removeClass("spinner-border spinner-border-sm").addClass("spinner-border spinner-border-sm");

            $(".AdType_Broad_Spend").removeClass("spinner-border spinner-border-sm").addClass("spinner-border spinner-border-sm");
            $(".AdType_Broad_Sales").removeClass("spinner-border spinner-border-sm").addClass("spinner-border spinner-border-sm");
            $(".AdType_Broad_ACoS").removeClass("spinner-border spinner-border-sm").addClass("spinner-border spinner-border-sm");
            
            $(".AdType_Phrase_Spend").removeClass("spinner-border spinner-border-sm").addClass("spinner-border spinner-border-sm");
            $(".AdType_Phrase_Sales").removeClass("spinner-border spinner-border-sm").addClass("spinner-border spinner-border-sm");
            $(".AdType_Phrase_ACoS").removeClass("spinner-border spinner-border-sm").addClass("spinner-border spinner-border-sm");
            
            $(".AdType_Exact_Spend").removeClass("spinner-border spinner-border-sm").addClass("spinner-border spinner-border-sm");
            $(".AdType_Exact_Sales").removeClass("spinner-border spinner-border-sm").addClass("spinner-border spinner-border-sm");
            $(".AdType_Exact_ACoS").removeClass("spinner-border spinner-border-sm").addClass("spinner-border spinner-border-sm");

            $(".AdType_SB_Spend").removeClass("spinner-border spinner-border-sm").addClass("spinner-border spinner-border-sm");
            $(".AdType_SB_Sales").removeClass("spinner-border spinner-border-sm").addClass("spinner-border spinner-border-sm");
            $(".AdType_SB_ACoS").removeClass("spinner-border spinner-border-sm").addClass("spinner-border spinner-border-sm");

            $(".AdType_SBV_Spend").removeClass("spinner-border spinner-border-sm").addClass("spinner-border spinner-border-sm");
            $(".AdType_SBV_Sales").removeClass("spinner-border spinner-border-sm").addClass("spinner-border spinner-border-sm");
            $(".AdType_SBV_ACoS").removeClass("spinner-border spinner-border-sm").addClass("spinner-border spinner-border-sm");
        }

        ,remove_spinner_performance_per_ad_type:function(){
            $(".AdType_Automatic_Spend").removeClass("spinner-border spinner-border-sm");
            $(".AdType_Automatic_Sales").removeClass("spinner-border spinner-border-sm");
            $(".AdType_Automatic_ACoS").removeClass("spinner-border spinner-border-sm");

            $(".AdType_Broad_Spend").removeClass("spinner-border spinner-border-sm");
            $(".AdType_Broad_Sales").removeClass("spinner-border spinner-border-sm");
            $(".AdType_Broad_ACoS").removeClass("spinner-border spinner-border-sm");
            
            $(".AdType_Phrase_Spend").removeClass("spinner-border spinner-border-sm");
            $(".AdType_Phrase_Sales").removeClass("spinner-border spinner-border-sm");
            $(".AdType_Phrase_ACoS").removeClass("spinner-border spinner-border-sm");
            
            $(".AdType_Exact_Spend").removeClass("spinner-border spinner-border-sm");
            $(".AdType_Exact_Sales").removeClass("spinner-border spinner-border-sm");
            $(".AdType_Exact_ACoS").removeClass("spinner-border spinner-border-sm");

            $(".AdType_SB_Spend").removeClass("spinner-border spinner-border-sm");
            $(".AdType_SB_Sales").removeClass("spinner-border spinner-border-sm");
            $(".AdType_SB_ACoS").removeClass("spinner-border spinner-border-sm");

            $(".AdType_SBV_Spend").removeClass("spinner-border spinner-border-sm");
            $(".AdType_SBV_Sales").removeClass("spinner-border spinner-border-sm");
            $(".AdType_SBV_ACoS").removeClass("spinner-border spinner-border-sm");
        }

        ,set_dashboard_performance_per_ad_type:function(response){
            let ad_sales =  $("#dashboard_ad_sales").val();
            $.each(eval(response.rsAutomatic),function(obj,val){
                $(".AdType_Automatic_Spend").html('$'+ format_number(`${val.Spend}`));
                $(".AdType_Automatic_Sales").html('$'+ format_number(`${val.Sales}`));
                $(".AdType_Automatic_ACoS").html(format_number(`${val.ACoS}`) + ' %');
                $(".AdType_Automatic_PBar").removeAttr('style');
                let tmp = (val.Sales/ad_sales).toFixed(2) * 100;
                $(".AdType_Automatic_PBar").attr('style', "width: " + tmp + '%');
                return false;
            });

            $.each(eval(response.rsBroad),function(obj,val){
                $(".AdType_Broad_Spend").html('$'+ format_number(`${val.Spend}`));
                $(".AdType_Broad_Sales").html('$'+ format_number(`${val.Sales}`));
                $(".AdType_Broad_ACoS").html(format_number(`${val.ACoS}`) + ' %');
                $(".AdType_Broad_PBar").removeAttr('style');
                let tmp = (val.Sales/ad_sales).toFixed(2) * 100;
                $(".AdType_Broad_PBar").attr('style', "width: " + tmp + '%');
                return false;
            });

            $.each(eval(response.rsPhrase),function(obj,val){
                $(".AdType_Phrase_Spend").html('$'+ format_number(`${val.Spend}`));
                $(".AdType_Phrase_Sales").html('$'+ format_number(`${val.Sales}`));
                $(".AdType_Phrase_ACoS").html(format_number(`${val.ACoS}`) + ' %');
                $(".AdType_Phrase_PBar").removeAttr('style');
                let tmp = (val.Sales/ad_sales).toFixed(2) * 100;
                $(".AdType_Phrase_PBar").attr('style', "width: " + tmp + '%');
                return false;
            });

            $.each(eval(response.rsExact),function(obj,val){
                $(".AdType_Exact_Spend").html('$'+ format_number(`${val.Spend}`));
                $(".AdType_Exact_Sales").html('$'+ format_number(`${val.Sales}`));
                $(".AdType_Exact_ACoS").html(format_number(`${val.ACoS}`) + ' %');
                $(".AdType_Exact_PBar").removeAttr('style');
                let tmp = (val.Sales/ad_sales).toFixed(2) * 100;
                $(".AdType_Exact_PBar").attr('style', "width: " + tmp + '%');
                return false;
            });

            $.each(eval(response.rsSB),function(obj,val){
                $(".AdType_SB_Spend").html('$'+ format_number(`${val.Spend}`));
                $(".AdType_SB_Sales").html('$'+ format_number(`${val.Sales}`));
                $(".AdType_SB_ACoS").html(format_number(`${val.ACoS}`) + ' %');
                $(".AdType_SB_PBar").removeAttr('style');
                let tmp = (val.Sales/ad_sales).toFixed(2) * 100;
                $(".AdType_SB_PBar").attr('style', "width: " + tmp + '%');
                return false;
            });

            $.each(eval(response.rsSBVideo),function(obj,val){
                $(".AdType_SBV_Spend").html('$'+ format_number(`${val.Spend}`));
                $(".AdType_SBV_Sales").html('$'+ format_number(`${val.Sales}`));
                $(".AdType_SBV_ACoS").html(format_number(`${val.ACoS}`) + ' %');
                $(".AdType_SBV_PBar").removeAttr('style');
                let tmp = (val.Sales/ad_sales).toFixed(2) * 100;
                $(".AdType_SBV_PBar").attr('style', "width: " + tmp + '%');
                return false;
            });

        } // (End Of) => set_dashboard_performance_per_ad_type:function(response)

        ,get_dashboard_performance_per_ad_type:function(){
            let CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
            let main_url =$('meta[name="main-url"]').attr('content');
            let text_date = $('#dashboard_dates').data('daterangepicker');
            let startDate =  text_date.startDate.format('YYYY/MM/DD');
            let endDate =  text_date.endDate.format('YYYY/MM/DD');
            let profile_id = $('#profiles-select').val()?$('#profiles-select').val().trim():"";

            
            dashboard_index.set_loading_performance_per_ad_type();
            $.ajax({
                url: main_url + "/home/performance_per_ad_type",
                type: 'GET',
                data: {
                    _token: CSRF_TOKEN,
                    startDate: startDate,
                    endDate: endDate,
                    profile_id: profile_id
                },
                success: function (response) {
                    if (response.Level == "success") {
                        dashboard_index.remove_spinner_performance_per_ad_type();
                        dashboard_index.set_dashboard_performance_per_ad_type(response);
                    }else{
                        dashboard_index.remove_spinner_performance_per_ad_type();
                        dashboard_index.set_default_performance_per_ad_type("0.00");
                        CommonScript.set_error_message(response.Message)
                    }
                },error: function(xhr, exception,errorThrown){
                    let msg = '';
                    if(xhr.status === 0){
                        msg = 'Not connected.\n Verify your Network.';
                    }else if(xhr.status == 404){
                        msg = "Page not found!";
                    }else if(xhr.status == 500){
                        msg =  'Internal Server Error [500].';
                    }else if(exception === 'parsererror'){
                        msg = 'Requested JSON parse failed.';
                    }else if(exception === 'timeout'){
                        msg = 'Time out error.';
                    }else if(exception === 'abort'){
                        msg = 'Ajax request aborted.';
                    }else{
                        msg = 'Uncaught Error.\n' + xhr.responseText;
                    }
                    dashboard_index.remove_spinner_performance_per_ad_type();
                    dashboard_index.set_default_performance_per_ad_type("0.00");
                    CommonScript.set_error_message(msg);
                }
            });
        } // (End Of) => get_dashboard_performance_per_ad_type:function(_startDate, _endDate, _profile_id)


    }; // (End of) => return 
}(); // (End of) => var dashboard_index = function()

// Initialize Dashboard JS Script
dashboard_index.init();
