<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Amz\Classes\FilterClass;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use App\Rule;
use App\Profile;
use DateTime;

class HomeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        #***************************************************************************
        # Copied codes from ViewServiceProvider.php=>boot()
        #***************************************************************************
        $currentnav = \Illuminate\Support\Facades\Request::segment(getURLSegment('current_slug'));
        $current_account_segment = trim(\Illuminate\Support\Facades\Request::segment(getURLSegment('current_account')));
        $current_profile_segment = trim(\Illuminate\Support\Facades\Request::segment(getURLSegment('current_profile')));
        if ($currentnav == 'users' || $currentnav == 'accounts' || $currentnav == 'rules' || $currentnav == 'permissions' || $currentnav == 'roles' || !$current_account_segment) {
            if (Auth::check() && count(Auth::user()->getAllUserAccount()) > 0 ) {
                $current_account_segment = Auth::user()->getAllUserAccount()->where('status', 1)->pluck('id', 'id')->first();
                $current_profile_segment = Auth::user()->getAllUserAccount()->where('status', 1)->first()->getActiveAccountProfiles()->pluck('id', 'id')->first();
            }
        } else if($current_account_segment == ""){
            $current_account_segment = Auth::user()->getAllUserAccount()->where('status', 1)->pluck('id', 'id')->first();
            $current_profile_segment = Auth::user()->getAllUserAccount()->where('status', 1)->first()->getActiveAccountProfiles()->pluck('id', 'id')->first();
        } else if($current_profile_segment == ""){
            $current_profile_segment = Auth::user()->getAllUserAccount()->where('status', 1)->first()->getActiveAccountProfiles()->pluck('id', 'id')->first();
        }
        $check_profile_exists = \App\Profile::where('id', $current_profile_segment)->where('account_id', $current_account_segment)->pluck('id', 'id')->first();
        if(trim($check_profile_exists) == ""){
            $current_profile_segment = Profile::where('account_id', '=', $current_account_segment)->where('status', '=', 1)
            ->orderBy('name', 'asc')->orderBy('countryCode', 'asc')
            ->pluck('id', 'id')->first();
        }

        $client_account_id = ($request->account_id?$request->account_id:$current_account_segment);
        $client_profile_id = ($request->profile_id?$request->profile_id:$current_profile_segment);
        $data['account_id'] = $client_account_id;
        $data['profile_id'] = $client_profile_id;

        $currentaccount = \App\Account::find($client_account_id);
        $profile = \App\Profile::where('id', $client_profile_id)->where('status', 1)->orderBy('name', 'asc')->orderBy('countryCode', 'asc')->first();
        $data['currentaccount'] = $currentaccount;
        $data['currentprofile'] = $profile;
        #***************************************************************************
        # (End Of) => Copied codes from ViewServiceProvider.php=>boot()
        #***************************************************************************

        
        $dashboard_type = ($request->dasboard?$request->dasboard:"main");
        if( !in_array($dashboard_type,['main','bid','negative'])){
            $dashboard_type = 'main';
        }
        $data['dashboard_type'] = $dashboard_type;
        $data['global_js_version'] = Str::uuid()->toString();
        
        if($dashboard_type == "bid" || $dashboard_type == "negative"){
            if (!Auth::user()->hasRole("Super Admin")) {
                $rules = Rule::where('created_by', Auth::user()->id);
            } else {
                $rules = Rule::orderBy('created_at', 'DESC');
            }
            $rules = $rules->whereIn('profiles_id', Profile::where('account_id', '=', $client_account_id)->where('status', '=', 1)->get(["id"]));
            if($client_profile_id > 0){
                $rules = $rules->where('profiles_id', '=',$client_profile_id);
            }

            $RequestType = $dashboard_type;
            if ($RequestType == "bid") {
                $rules = $rules->where('rule_action', '!=', 'addNegativeSearchTerm')->get();
            } else {
                $rules = $rules->where('rule_action', '=', 'addNegativeSearchTerm')->get();
            }
            
            $data['rules'] = $rules;
            $filterClass = new FilterClass(ENTITY_CAMPAIGN);
            $filters = $filterClass->getReportingColumnforRule_v2();
            $data['filters'] = $filters;
            $data['type'] = $RequestType;
            $data['dashboard'] = "yes";
        }
        
        $data['super_admin'] = Auth::user()->hasRole("Super Admin")?"yes":"no";
        return view('home', $data);
    }
    
    public function requestActions(Request $request)
    {
        try {
            $action = $request->get('ajaxAction');
            switch ($action) {
                case 'dashboard_data':
                    return $this->dashboard_data($request);
                    break;
                default:
                    dd($request->all());
                    break;
           }
        }catch (\Exception $e) {
            return response()->json(['Level' => "error", 'Message' => $e->getMessage()]);
        }
    }

    function is_whole_month($pStartDate, $pEndDate){
        $tmpDateEnd = date('Y-m-t', strtotime($pStartDate)); // Get Last_day of the months
        $tmpDateStart =  new DateTime($tmpDateEnd);
        $tmpDateStart = $tmpDateStart->format('Y-m-01'); // Get First day of the month
        return (
            date('Y-m-d', strtotime($tmpDateEnd)) == date('Y-m-d', strtotime($pEndDate)) && 
            date('Y-m-d', strtotime($tmpDateStart)) == date('Y-m-d', strtotime($pStartDate)) 
            //date('Y-m-d', strtotime($tmpDateEnd)) . " == " . date('Y-m-d', strtotime($pEndDate)) . " ; " . date('Y-m-d', strtotime($tmpDateStart)) . " == " .  date('Y-m-d', strtotime($pStartDate))
        );
    }

    function calculate_last_period($pChosenLabel,$pStartDate, $pEndDate, &$prevDateStart, &$prevDateEnd){
        $custom_whole_month = ($pChosenLabel == "Custom Range")? $this->is_whole_month($pStartDate,$pEndDate) : false;
        $pChosenLabel = strtoupper(trim($pChosenLabel));
        if($pChosenLabel == "THIS MONTH" || $pChosenLabel == "LAST MONTH" || $custom_whole_month == true){
            $prevDateEnd = date('Y-m-t', strtotime($pStartDate. ' - 1 months')); // Get Last_day of the months
            $prevDateStart =  new DateTime($prevDateEnd);
            $prevDateStart = $prevDateStart->format('Y-m-01'); // Get First day of the month
        }else{
            # **********************************************************************
            # Calculate previous days period => Today, Yesterday, Last 7 Days, Last 30 Days, Custom Range
            # **********************************************************************
            $days_interval = $this->get_days_interval($pStartDate,$pEndDate);
            $prevDateEnd =  new DateTime($pStartDate);
            $prevDateEnd =  $prevDateEnd->modify("-1 day")->format('Y-m-d');
            $prevDateStart =  new DateTime($prevDateEnd);
            $prevDateStart =  $prevDateStart->modify("-$days_interval day")->format('Y-m-d');
            # **********************************************************************
            # (End Of) => Calculate previous days period
            # **********************************************************************
        }
    }

    public function dashboard_data(Request $request)
    {
        try {
            $chosenLabel = $request->chosenLabel;
            $startDate = date("Y-m-d", strtotime($request->startDate));
            $endDate = date("Y-m-d", strtotime($request->endDate));
            $profile_id = $request->profile_id;
            $tmpProfiles = Profile::where('id', $profile_id)->get(["account_id", "currencyCode", "profileId"])->first();
            $profileId = $tmpProfiles->profileId;
            $account_id = $tmpProfiles->account_id;
            $currencyCode = $tmpProfiles->currencyCode;
            $prevDateStart = "";
            $prevDateEnd = "";
            
            $this->calculate_last_period($chosenLabel, $startDate, $endDate, $prevDateStart, $prevDateEnd);
           
            #Percentage = ((Current Value - Previous Value) / Previous Value) × 100
            $sql = '
                Select
                    profile_id
                    ,format(cur_cost,2) As cur_cost
                    ,format(cur_acos,2) As cur_acos
                    ,format(cur_attributedSales7d,2) As cur_attributedSales7d
                    ,round(cur_attributedSales7d,2) As cur_attributedSales7d_nf
                    ,prev_cost, prev_acos, prev_attributedSales7d
                    ,IfNull((Case
                        When IfNull(rpt.prev_cost,0) = 0 And IfNull(rpt.cur_cost,0) != 0 Then 100.00
                        Else round((((IfNull(rpt.cur_cost,0) - IfNull(rpt.prev_cost,0)) / IfNull(rpt.prev_cost,0)) * 100),2)
                    End),0.00) As cur_cost_pct
                    ,Round(
                        IfNull(rpt.cur_acos,0) - IfNull(rpt.prev_acos,0),
                    2) As cur_acos_pct
                    ,IfNull((Case 
                        When IfNull(rpt.prev_attributedSales7d,0) = 0 And IfNull(rpt.cur_attributedSales7d,0) != 0 Then 100.00
                        Else round((((IfNull(rpt.cur_attributedSales7d,0) - IfNull(rpt.prev_attributedSales7d,0)) / IfNull(rpt.prev_attributedSales7d,0)) * 100),2)
                    End),0.00) As cur_attributedSales7d_pct
                From
                (
                    Select
                        base.profile_id
                        ,IfNull(curStat.cur_cost,0) +  IfNull(curSBV.cur_cost,0) +  IfNull(curSB.cur_cost,0) As cur_cost
                        ,IfNull(curStat.cur_attributedSales7d,0) +  IfNull(curSBV.cur_AttributedSales14d,0) +  IfNull(curSB.cur_AttributedSales14d,0) As cur_attributedSales7d
                        
                        ,ROUND((
                            IFNULL(
                              CAST(( IfNull(curStat.cur_cost,0.00) +  IfNull(curSBV.cur_cost,0.00) +  IfNull(curSB.cur_cost,0.00) ) AS DECIMAL(24,2))
                              / 
                              CAST((IfNull(curStat.cur_attributedSales7d,0.00) +  IfNull(curSBV.cur_AttributedSales14d,0.00) +  IfNull(curSB.cur_AttributedSales14d,0.00)) AS DECIMAL(24,2))
                            ,0.00) *100
                          ),2)  As cur_acos
                        
                        ,IfNull(prevStat.prev_cost,0) +  IfNull(prevSBV.prev_cost,0) +  IfNull(prevSB.prev_cost,0) As prev_cost
                        ,IfNull(prevStat.prev_attributedSales7d,0) +  IfNull(prevSBV.prev_AttributedSales14d,0) +  IfNull(prevSB.prev_AttributedSales14d,0) As prev_attributedSales7d
                        
                        ,ROUND((
                            IFNULL( 
                              CAST(( IfNull(prevStat.prev_cost,0) +  IfNull(prevSBV.prev_cost,0) +  IfNull(prevSB.prev_cost,0)) AS DECIMAL(24,2))
                             /  CAST(( IfNull(prevStat.prev_attributedSales7d,0) +  IfNull(prevSBV.prev_AttributedSales14d,0) +  IfNull(prevSB.prev_AttributedSales14d,0) )AS DECIMAL(24,2))
                           ,0.00)  * 100 
                         ),2)  As prev_acos

                    From (Select '. $profile_id .' As profile_id, '. $profileId .' As profileId) As base
                    Left Join(
                        Select
                            `rp`.`profileId`
                            ,IfNull(SUM(rp.cost),0) as cur_cost
                            ,IfNull(SUM(rp.attributedSales7d), 0) as cur_attributedSales7d
                        From `productads_'.$account_id.'` as `et`
                        join productads_reports_'.$account_id.' as rp on `rp`.`adId` = `et`.`adId` and `report_date` Between "'. $startDate .'" And "'. $endDate .'"
                        Where `et`.`profile_id` = '. $profile_id .'  Group By `rp`.`profileId`
                    ) As curStat using(profileId)
                    Left Join(
                        Select
                            `rp`.`profileId`
                            ,IfNull(SUM(rp.cost),0) as prev_cost
                            ,IfNull(SUM(rp.attributedSales7d), 0) as prev_attributedSales7d
                        From `productads_'.$account_id.'` as `et`
                        join productads_reports_'.$account_id.' as rp on `rp`.`adId` = `et`.`adId` and `report_date` Between "'. $prevDateStart .'" And "'. $prevDateEnd .'"
                        Where `et`.`profile_id` = '. $profile_id .' Group By `rp`.`profileId`
                    ) As prevStat using(profileId)

                    Left Join (
                        select
                            et.profileId
                            ,IfNull(SUM(et.cost),0) as cur_cost
                            ,IfNull(SUM(et.AttributedSales14d), 0) as cur_AttributedSales14d
                        from `campaigns_sbv_reports_'.$account_id.'` as et
                        where report_date Between "'. $startDate .'" And "'. $endDate .'" and et.profileId = '. $profileId .'
                        group by et.profileId
                    ) As curSBV using(profileId)
                    
                    Left Join (
                        select
                            et.profileId
                            ,IfNull(SUM(et.cost),0) as prev_cost
                            ,IfNull(SUM(et.AttributedSales14d), 0) as prev_AttributedSales14d
                        from `campaigns_sbv_reports_'.$account_id.'` as et
                        where report_date Between "'. $prevDateStart .'" And "'. $prevDateEnd .'" and et.profileId = '. $profileId .'
                        group by et.profileId
                    ) As prevSBV using(profileId)

                    Left Join (
                        select
                            et.profileId
                            ,IfNull(SUM(et.cost),0) as cur_cost
                            ,IfNull(SUM(et.AttributedSales14d), 0) as cur_AttributedSales14d
                        from `campaigns_sb_reports_'.$account_id.'` as et
                        where report_date Between "'. $startDate .'" And "'. $endDate .'" and et.profileId = '. $profileId .'
                        group by et.profileId
                    ) As curSB using(profileId)
                    
                    Left Join (
                        select
                            et.profileId
                            ,IfNull(SUM(et.cost),0) as prev_cost
                            ,IfNull(SUM(et.AttributedSales14d), 0) as prev_AttributedSales14d
                        from `campaigns_sb_reports_'.$account_id.'` as et
                        where report_date Between "'. $prevDateStart .'" And "'. $prevDateEnd .'" and et.profileId = '. $profileId .'
                        group by et.profileId
                    ) As prevSB using(profileId)
                ) As rpt
            ';
            
            //dd($sql); 
            $results = DB::select($sql);
            
            $sql = "
                Call webskoppc.sp_dashboard_wasted_ad_spend(
                    $account_id
                    ,$profile_id
                    ,'$profileId'
                    ,'$startDate'
                    ,'$endDate'
                    ,'$prevDateStart'
                    ,'$prevDateEnd'
                );
            ";
            $rsAdSpend = DB::select($sql);
            
            return response()->json(['Level' => "success"
                , 'results' => $results
                , 'rsAdSpend' => $rsAdSpend
                , 'currencyCode'=>$currencyCode
                , 'chosenLabel'=>$chosenLabel
                , 'dateStart'=>$startDate
                , 'dateEnd'=>$endDate
                , 'prevDateStart'=>$prevDateStart
                , 'prevDateEnd'=>$prevDateEnd
                , 'days_interval' => $this->get_days_interval($startDate,$endDate)
                , 'days_interval_prev' => $this->get_days_interval($prevDateStart,$prevDateEnd)
                , 'custom_whole_month' => $this->is_whole_month($startDate,$endDate)
            ]);
        }catch (\Exception $e) {
            return response()->json(['Level' => "error", 'Message' => $e->getMessage()]);
        }
    }

    private function get_days_interval($pDateStart, $pDateEnd){
        $datetime1 = new DateTime($pDateStart);
        $datetime2 = new DateTime($pDateEnd);
        $interval =  $datetime1->diff($datetime2);
        return $interval->days;
    }

    public function dashboard_data_performance_per_ad_type(Request $request){
        try {
            $startDate = date("Y-m-d", strtotime($request->startDate));
            $endDate = date("Y-m-d", strtotime($request->endDate));
            $profile_id = $request->profile_id;
            $tmpProfiles = Profile::where('id', $profile_id)->get(["account_id", "currencyCode", "profileId"])->first();
            $account_id = $tmpProfiles->account_id;
            
            $sql = "
                Call webskoppc.sp_dashboard_data_performance_per_ad_type_automatic(
                    $account_id
                    ,$profile_id
                    ,'$startDate'
                    ,'$endDate'
                );
            ";
            $rsAutomatic = DB::select($sql);
            
            $sql = "
                Call webskoppc.sp_dashboard_data_performance_per_ad_type_broad(
                    $account_id
                    ,$profile_id
                    ,'$startDate'
                    ,'$endDate'
                );
            ";
            $rsBroad = DB::select($sql);
    
            $sql = "
                Call webskoppc.sp_dashboard_data_performance_per_ad_type_exact(
                    $account_id
                    ,$profile_id
                    ,'$startDate'
                    ,'$endDate'
                );
            ";
            $rsExact = DB::select($sql);
            
            $sql = "
                Call webskoppc.sp_dashboard_data_performance_per_ad_type_phrase(
                    $account_id
                    ,$profile_id
                    ,'$startDate'
                    ,'$endDate'
                );
            ";
            $rsPhrase = DB::select($sql);
            
            $sql = "
                Call webskoppc.sp_dashboard_data_performance_per_ad_type_sb(
                    $account_id
                    ,$profile_id
                    ,'$startDate'
                    ,'$endDate'
                );
            ";
            $rsSB = DB::select($sql);
    
            $sql = "
                Call webskoppc.sp_dashboard_data_performance_per_ad_type_sb_video(
                    $account_id
                    ,$profile_id
                    ,'$startDate'
                    ,'$endDate'
                );
            ";
            $rsSBVideo = DB::select($sql);
            
            return response()->json([
                'Level' => "success" 
                ,'rsAutomatic' => $rsAutomatic
                ,'rsBroad' => $rsBroad
                ,'rsPhrase' => $rsPhrase
                ,'rsExact' => $rsExact
                ,'rsSB' => $rsSB
                ,'rsSBVideo' => $rsSBVideo
            ]);
        }catch (\Exception $e) {
            return response()->json(['Level' => "error", 'Message' => $e->getMessage()]);
        }
    } // (End Of) => public function dashboard_data_performance_per_ad_type(Request $request)


} // (End Of) => class HomeController extends Controller
