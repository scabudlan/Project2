<!-- page start-->
<div class="mb-2 d-none" id="div_error_placeholder"></div>
<div class="row">
    <div class="col-12 mb-3">
        <div class="input-group">
            <div id="dashboard_dates" style="width: auto; max-width: 300px !important;" class="mt-2 overflow-hidden form-control">
                <i class="align-middle feather-14" data-feather="calendar" ></i>&nbsp;
                <span></span> <i class="align-middle feather-18" data-feather="chevron-down"></i>
            </div>
        </div>
    </div>   
</div>
<div class="row">
    <div class="col-12 col-sm-6 col-xxl-2 d-flex">
        <div class="card flex-fill ad-spend-body">
            <div class="card-body py-3">
                <div class="d-flex align-items-start">
                    <div class="flex-grow-1">
                        <h3 class="mb-2 ad-spend">$ 0.00</h3>
                        <p class="mb-2 fs-4 fw-bold">Ad Spend</p>
                    </div>
                    <div class="d-inline-block ms-3">
                        <div class="stat currencyCode">
                            <i class="align-middle text-success" data-feather="dollar-sign"></i>
                        </div>
                    </div>
                </div>
                <div class="d-flex mt-3">
                    <div class="mb-0">
                        <span class="badge badge-soft-info me-2 ad-spend-pct"> 0.00% </span>
                        <span class="text-muted">Change from last period</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-xxl-2 d-flex">
        <div class="card flex-fill ad-sales-body">
            <div class="card-body py-3">
                <div class="d-flex align-items-start">
                    <div class="flex-grow-1">
                        <h3 class="mb-2 ad-sales">$ 0.00</h3>
                        <p class="mb-2 fs-4 fw-bold">Ad Sales</p>
                        <input type="hidden" id="dashboard_ad_sales" />
                    </div>
                    <div class="d-inline-block ms-3">
                        <div class="stat currencyCode">
                            <i class="align-middle text-success" data-feather="dollar-sign"></i>
                        </div>
                    </div>
                </div>
                <div class="d-flex mt-3">
                    <div class="mb-0">
                        <span class="badge badge-soft-info me-2 ad-sales-pct"> 0.00% </span>
                        <span class="text-muted">Change from last period</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    {{-- 
    <div class="col-12 col-sm-6 col-xxl-2 d-flex">
        <div class="card flex-fill total-sales-body">
            <div class="card-body py-3">
                <div class="d-flex align-items-start">
                    <div class="flex-grow-1">
                        <h3 class="mb-2 total-sales"><span>$</span> 0.00</h3>
                        <p class="mb-2 fs-4 fw-bold">Total Sales</p>
                    </div>
                    <div class="d-inline-block ms-3">
                        <div class="stat currencyCode">
                            <i class="align-middle text-success" data-feather="dollar-sign"></i>
                        </div>
                    </div>
                </div>
                <div class="d-flex mt-3">
                    <div class="mb-0">
                        <span class="badge badge-soft-info me-2 total-sales-pct"> 0.00% </span>
                        <span class="text-muted">Change from last period</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    --}}
    <div class="col-12 col-sm-6 col-xxl-2 d-flex">
        <div class="card flex-fill acos-body">
            <div class="card-body py-3">
                <div class="d-flex align-items-start">
                    <div class="flex-grow-1">
                        <h3 class="mb-2 acos">0.00</h3>
                        <p class="mb-2 fs-4 fw-bold">ACoS</p>
                    </div>
                    <div class="d-inline-block ms-3">
                        <div class="stat">
                            <i class="align-middle text-success" data-feather="percent"></i>
                        </div>
                    </div>
                </div>
                <div class="d-flex mt-3">
                    <div class="mb-0">
                        <span class="badge badge-soft-info me-2 acos-pct"> 0.00% </span>
                        <span class="text-muted">Change from last period</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    {{-- 
    <div class="col-12 col-sm-6 col-xxl-2 d-flex tacos-body">
        <div class="card flex-fill">
            <div class="card-body py-3">
                <div class="d-flex align-items-start">
                    <div class="flex-grow-1">
                        <h3 class="mb-2 tacos">$ 0.00</h3>
                        <p class="mb-2 fs-4 fw-bold">TACoS</p>
                    </div>
                    <div class="d-inline-block ms-3">
                        <div class="stat currencyCode">
                            <i class="align-middle text-success" data-feather="dollar-sign"></i>
                        </div>
                    </div>
                </div>
                <div class="d-flex mt-3">
                    <div class="mb-0">
                        <span class="badge badge-soft-info me-2 tacos-pct"> 0.00% </span>
                        <span class="text-muted">Change from last period</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    --}}
    <div class="col-12 col-sm-6 col-xxl-2 d-flex">
        <div class="card flex-fill wasted_ad_spend-body">
            <div class="card-body py-3">
                <div class="d-flex align-items-start">
                    <div class="flex-grow-1">
                        <h3 class="mb-2 wasted_ad_spend">0.00</h3>
                        <p class="mb-2 fs-4 fw-bold">Wasted Ad Spend</p> 
                    </div>
                    <div class="d-inline-block ms-3">
                        <div class="stat">
                            <i class="align-middle text-success" data-feather="percent"></i>
                        </div>
                    </div>
                </div>
                <div class="d-flex mt-3">
                    <div class="mb-0">
                        <span class="badge badge-soft-info me-2 wasted_ad_spend-pct"> 0.00% </span>
                        <span class="text-muted">Change from last period</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- page end-->