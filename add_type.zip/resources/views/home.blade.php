@extends('layouts.app')

@section('content')
{{-- 
    @if(\Session::has('flash_message'))
        <div class="alert alert-success alert-block">{{\Session::get('flash_message')}}</div>
    @endif
--}}
<!-- page start-->
<div class="row" id="record_body">
    {{-- v1.0 Dashboard --}}
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link dashboard-link @if($dashboard_type=="main") active @endif" onclick="javascript:dashboard_tab_handler(this);" attr-dashboard_type="main">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link dashboard-link @if($dashboard_type=="bid") active @endif"  onclick="javascript:dashboard_tab_handler(this);" attr-dashboard_type="bid">Bid Changes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link dashboard-link @if($dashboard_type=="negative") active @endif" onclick="javascript:dashboard_tab_handler(this);" attr-dashboard_type="negative">Negatives</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link dashboard-link disabled">ASINs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link dashboard-link disabled">Placements</a>
                    </li>
                </ul>
            </div>
            <div class="card-body pt-0 pb-0">
                <div class="tab-content">
                    <div class="tab-pane fade @if($dashboard_type=="main") show active @endif" id="Dashboard" role="tabpanel">
                        @if($dashboard_type=="main")
                            @include('dashboard.index')
                        @endif
                    </div>
                    <div class="tab-pane fade @if($dashboard_type=="bid") show active @endif" id="Bid_Changes" role="tabpanel">
                        @if($dashboard_type=="bid")
                            @include('rules.index_dashboard')
                        @endif
                    </div>
                    <div class="tab-pane fade @if($dashboard_type=="negative") show active @endif" id="Negative" role="tabpanel">
                        @if($dashboard_type=="negative")
                            @include('rules.index_dashboard')
                        @endif
                    </div>
                    <div class="tab-pane fade" id="ASINs" role="tabpanel">
                        ASINs
                    </div>
                    <div class="tab-pane fade" id="Placements" role="tabpanel">
                        Placements
                    </div>
                </div>
            </div>
        </div>
    </div>
    {{-- (End) => v1.0 Dashboard --}}
    
    {{-- August 1, 2022 Major Update --}}
    @if($dashboard_type=="main" && \Auth::user()->hasRole('Super Admin'))

    <div class="col-12">
        <h1 class="h4 mb-1">Performance per Ad Type</h1>
        <div class="row">
            <div class="col-sm-6 col-md-2 text-center">
                <div class="card flex-fill">
                    <div class="card-header">
                        <h5 class="card-title mb-0 mt-2">Automatic</h5>
                    </div>
                    <div class="card-body my-0 pt-0">
                        <div class="row d-flex align-items-center mb-3">
                            <div class="col-8">
                                <h3 class="d-flex align-items-center mb-0 fw-light AdType_Automatic_Spend">
                                    $0.00
                                </h3>
                            </div>
                            <div class="col-4 text-end">
                                <span class="text-muted">Spend</span>
                            </div>
                        </div>
                        <div class="row d-flex align-items-center mb-3">
                            <div class="col-8">
                                <h3 class="d-flex align-items-center mb-0 fw-light AdType_Automatic_Sales">
                                    $0.00
                                </h3>
                            </div>
                            <div class="col-4 text-end">
                                <span class="text-muted">Sales</span>
                            </div>
                        </div>
                        <div class="row d-flex align-items-center mb-3">
                            <div class="col-8">
                                <h3 class="d-flex align-items-center mb-0 fw-light AdType_Automatic_ACoS">
                                    0.00 %
                                </h3>
                            </div>
                            <div class="col-4 text-end">
                                <span class="text-muted">ACoS</span>
                            </div>
                        </div>
                        <div class="progress progress-sm shadow-sm mb-1">
                            <div class="progress-bar bg-primary AdType_Automatic_PBar" role="progressbar" style="width: 100%"></div>
                        </div>
                    </div>
                </div>
            </div>
        
            <div class="col-sm-6 col-md-2 text-center">
                <div class="card flex-fill">
                    <div class="card-header">
                        <h5 class="card-title mb-0 mt-2">Broad</h5>
                    </div>
                    <div class="card-body my-0 pt-0">
                        <div class="row d-flex align-items-center mb-3">
                            <div class="col-8">
                                <h3 class="d-flex align-items-center mb-0 fw-light AdType_Broad_Spend">
                                    $0.00
                                </h3>
                            </div>
                            <div class="col-4 text-end">
                                <span class="text-muted">Spend</span>
                            </div>
                        </div>
                        <div class="row d-flex align-items-center mb-3">
                            <div class="col-8">
                                <h3 class="d-flex align-items-center mb-0 fw-light AdType_Broad_Sales">
                                    $0.00
                                </h3>
                            </div>
                            <div class="col-4 text-end">
                                <span class="text-muted">Sales</span>
                            </div>
                        </div>
                        <div class="row d-flex align-items-center mb-3">
                            <div class="col-8">
                                <h3 class="d-flex align-items-center mb-0 fw-light AdType_Broad_ACoS">
                                    0.00 %
                                </h3>
                            </div>
                            <div class="col-4 text-end">
                                <span class="text-muted">ACoS</span>
                            </div>
                        </div>
                        <div class="progress progress-sm shadow-sm mb-1">
                            <div class="progress-bar bg-secondary AdType_Broad_PBar" role="progressbar" style="width: 57%"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-md-2 text-center">
                <div class="card flex-fill">
                    <div class="card-header">
                        <h5 class="card-title mb-0 mt-2">Phrase</h5>
                    </div>
                    <div class="card-body my-0 pt-0">
                        <div class="row d-flex align-items-center mb-3">
                            <div class="col-8">
                                <h3 class="d-flex align-items-center mb-0 fw-light AdType_Phrase_Spend">
                                    $0.00
                                </h3>
                            </div>
                            <div class="col-4 text-end">
                                <span class="text-muted">Spend</span>
                            </div>
                        </div>
                        <div class="row d-flex align-items-center mb-3">
                            <div class="col-8">
                                <h3 class="d-flex align-items-center mb-0 fw-light AdType_Phrase_Sales">
                                    $0.00
                                </h3>
                            </div>
                            <div class="col-4 text-end">
                                <span class="text-muted">Sales</span>
                            </div>
                        </div>
                        <div class="row d-flex align-items-center mb-3">
                            <div class="col-8">
                                <h3 class="d-flex align-items-center mb-0 fw-light AdType_Phrase_ACoS">
                                    0.00 %
                                </h3>
                            </div>
                            <div class="col-4 text-end">
                                <span class="text-muted">ACoS</span>
                            </div>
                        </div>
                        <div class="progress progress-sm shadow-sm mb-1">
                            <div class="progress-bar bg-primary AdType_Phrase_PBar" role="progressbar" style="width: 57%"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-md-2 text-center">
                <div class="card flex-fill">
                    <div class="card-header">
                        <h5 class="card-title mb-0 mt-2">Exact</h5>
                    </div>
                    <div class="card-body my-0 pt-0">
                        <div class="row d-flex align-items-center mb-3">
                            <div class="col-8">
                                <h3 class="d-flex align-items-center mb-0 fw-light AdType_Exact_Spend">
                                    $0.00
                                </h3>
                            </div>
                            <div class="col-4 text-end">
                                <span class="text-muted">Spend</span>
                            </div>
                        </div>
                        <div class="row d-flex align-items-center mb-3">
                            <div class="col-8">
                                <h3 class="d-flex align-items-center mb-0 fw-light AdType_Exact_Sales">
                                    $0.00
                                </h3>
                            </div>
                            <div class="col-4 text-end">
                                <span class="text-muted">Sales</span>
                            </div>
                        </div>
                        <div class="row d-flex align-items-center mb-3">
                            <div class="col-8">
                                <h3 class="d-flex align-items-center mb-0 fw-light AdType_Exact_ACoS">
                                    0.00 %
                                </h3>
                            </div>
                            <div class="col-4 text-end">
                                <span class="text-muted">ACoS</span>
                            </div>
                        </div>
                        <div class="progress progress-sm shadow-sm mb-1">
                            <div class="progress-bar bg-success AdType_Exact_PBar" role="progressbar" style="width: 57%"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-md-2 text-center">
                <div class="card flex-fill">
                    <div class="card-header">
                        <h5 class="card-title mb-0 mt-2">Sponsored Brand</h5>
                    </div>
                    <div class="card-body my-0 pt-0">
                        <div class="row d-flex align-items-center mb-3">
                            <div class="col-8">
                                <h3 class="d-flex align-items-center mb-0 fw-light AdType_SB_Spend">
                                    $0.00
                                </h3>
                            </div>
                            <div class="col-4 text-end">
                                <span class="text-muted">Spend</span>
                            </div>
                        </div>
                        <div class="row d-flex align-items-center mb-3">
                            <div class="col-8">
                                <h3 class="d-flex align-items-center mb-0 fw-light AdType_SB_Sales">
                                    $0.00
                                </h3>
                            </div>
                            <div class="col-4 text-end">
                                <span class="text-muted">Sales</span>
                            </div>
                        </div>
                        <div class="row d-flex align-items-center mb-3">
                            <div class="col-8">
                                <h3 class="d-flex align-items-center mb-0 fw-light AdType_SB_ACoS">
                                    0.00 %
                                </h3>
                            </div>
                            <div class="col-4 text-end">
                                <span class="text-muted">ACoS</span>
                            </div>
                        </div>
                        <div class="progress progress-sm shadow-sm mb-1">
                            <div class="progress-bar bg-primary AdType_SB_PBar" role="progressbar" style="width: 57%"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-md-2 text-center">
                <div class="card flex-fill">
                    <div class="card-header">
                        <h5 class="card-title mb-0 mt-2">Video</h5>
                    </div>
                    <div class="card-body my-0 pt-0">
                        <div class="row d-flex align-items-center mb-3">
                            <div class="col-8">
                                <h3 class="d-flex align-items-center mb-0 fw-light AdType_SBV_Spend">
                                    $0.00
                                </h3>
                            </div>
                            <div class="col-4 text-end">
                                <span class="text-muted">Spend</span>
                            </div>
                        </div>
                        <div class="row d-flex align-items-center mb-3">
                            <div class="col-8">
                                <h3 class="d-flex align-items-center mb-0 fw-light AdType_SBV_Sales">
                                    $0.00
                                </h3>
                            </div>
                            <div class="col-4 text-end">
                                <span class="text-muted">Sales</span>
                            </div>
                        </div>
                        <div class="row d-flex align-items-center mb-3">
                            <div class="col-8">
                                <h3 class="d-flex align-items-center mb-0 fw-light AdType_SBV_ACoS">
                                    0.00 %
                                </h3>
                            </div>
                            <div class="col-4 text-end">
                                <span class="text-muted">ACoS</span>
                            </div>
                        </div>
                        <div class="progress progress-sm shadow-sm mb-1">
                            <div class="progress-bar bg-info AdType_SBV_PBar" role="progressbar" style="width: 57%"></div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    @endif
    {{-- (End) => August 1, 2022 Major Update --}}
</div>
 <!-- page end-->
@endsection

@section('js')
    @if($dashboard_type=="bid" || $dashboard_type=="negative")
        @php
            jsScripts(['rules/index'], @$global_js_version);
            jsScripts(['common/rule-filters'], @$global_js_version);
        @endphp
        <script>
            $('.main-toggle').on('click', function () {
                $(this).toggleClass('on');

                let rule_id = $(this).attr('data-rule-id');

                if ($(this).hasClass('on')) {
                    changeStatus(1, rule_id)
                } else {
                    changeStatus(0, rule_id)
                }
            });

            function changeStatus(status, rule_id) {
                let CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
                $.ajax({
                    url: "{{url('/')}}" + "/rules/request-actions",
                    type: 'POST',
                    data: {
                        _token: CSRF_TOKEN,
                        ajaxAction: "change_status_rule",
                        status: status,
                        rule_id: rule_id
                    },
                    success: function (response) {

                    }
                });
            }
        </script>
    @endif
    <script>
        $('#account_id').change(function(){
           let account_id = $(this).val();
           $("#profile_id").empty();
            let count_options = 1;
            $.each(rsActiveAccountProfiles,function(obj, val){
                if(account_id == val.account_id){
                    let newOption =  new Option(`${val.name} (${val.countryCode})`, val.id , (count_options==1)?true:false, (count_options==1)?true:false);
                    $('#profile_id').append(newOption);
                    count_options++;
                }
            });
        });
    </script>
    @php
        jsScripts(['dashboard/index'], @$global_js_version);
    @endphp
    <script>
        var dashboard_type = "{{$dashboard_type}}";
        $( document ).ready(function() {
            // Init dashboard data
            dashboard_index.getDashBoardData();
        });

        function dashboard_tab_handler(Obj){
            let account_id = $("a.list-group-item.dashboard-account.active").attr("data-account-id");
            let profile_id = $("#profiles-select").val();
            // Get Selected Option Text
            //let profile_id_text = $( "#profiles-select option:selected").text();
            
            let attr_dashboard_type = $(Obj).attr("attr-dashboard_type")?$(Obj).attr("attr-dashboard_type"):"main";
            if(attr_dashboard_type != dashboard_type){
                dashboard_type = attr_dashboard_type;
                CommonScript.blockUI();
                location.href="{{url('/')}}" + "?dasboard=" + dashboard_type  + "&account_id=" + account_id+ "&profile_id=" + profile_id;
            }
        }
    </script>
@endsection

